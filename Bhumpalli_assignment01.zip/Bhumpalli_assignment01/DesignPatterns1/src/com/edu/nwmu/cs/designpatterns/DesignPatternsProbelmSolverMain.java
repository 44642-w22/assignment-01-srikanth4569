package com.edu.nwmu.cs.designpatterns;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Deque;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;

public class DesignPatternsProbelmSolverMain {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		DesignPatternsProbelmSolverMain mainApp = new DesignPatternsProbelmSolverMain();
		Scanner scanner = new Scanner(System.in);
		try {
		do {
		System.out.println("Enter problem number to solve:");
		String problemNo = scanner.nextLine();
		
			int iProblemNo = Integer.parseInt(problemNo);
			if(iProblemNo < 1 || iProblemNo > 10) {
				throw new Exception("Problem number should be entered between 1 and 10.");
			}
			switch (iProblemNo) {
			case 1:
				mainApp.promptInputsAndSolveProblem1(scanner);
				break;
			case 2:
				mainApp.promptInputsAndSolveProblem2(scanner);
				break;
			case 3:
				mainApp.promptInputsAndSolveProblem3(scanner);
				break;
			case 4:
				mainApp.promptInputsAndSolveProblem4(scanner);
				break;
			case 5:
				mainApp.promptInputsAndSolveProblem5(scanner);
				break;
			case 6:
				mainApp.promptInputsAndSolveProblem6(scanner);
				break;
			case 7:
				mainApp.promptInputsAndSolveProblem7(scanner);
				break;
			case 8:
				mainApp.promptInputsAndSolveProblem8(scanner);
				break;
			case 9:
				mainApp.promptInputsAndSolveProblem9(scanner);
				break;
			case 10:
				mainApp.promptInputsAndSolveProblem10(scanner);
				break;
			default:
				mainApp.exit();
				break;
			}
		}while(true);
		}catch(NumberFormatException e) { // gets executed only for number format exceptions
			System.out.println("You have entered a string which is not in number format");
		    mainApp.exit();
		}catch(Exception e) { // gets executed for all other exceptions
			System.out.println(e.getMessage());
			mainApp.exit();
		}

	}
	public void promptInputsAndSolveProblem1(Scanner sc) throws Exception {
		LinkedList<Integer> l1 = new LinkedList<Integer>();
		System.out.println("Enter the numbers to solve problem1. "
				+ "Press enter to input next number. When you are finished, type \"done\"");
		String inputStr = null;
		boolean isFinished = false;
		do {
			try {
			inputStr = sc.nextLine();
			int inputNo = Integer.parseInt(inputStr);
			if(inputNo > 0) 
			  l1.add(inputNo);
			else
			  throw new Exception("You have entered a non positive integer");
			}catch(NumberFormatException e) {
				if("done".equalsIgnoreCase(inputStr)) {
					isFinished = true;
				}
				else {
					throw new Exception("You have entered a non integer. Problem 1 accepts"
							+ " only numbers");
				}
			}
		}while(!isFinished);
		solveProblem1(l1);
	}
	
    public void promptInputsAndSolveProblem2(Scanner sc) throws Exception {
    	LinkedList<Integer> l1 = new LinkedList<Integer>();
    	System.out.println("Enter the number K");
    	String k = null;
    	int ik = 0;
    	String inputStr = null;
    	boolean isFinished = false;
    	try {
    		k = sc.nextLine();
    		ik = Integer.parseInt(k);
    		System.out.println("Enter the numbers to solve problem2. "
    				+ "Press enter to input next number. When you are finished,"
    				+ " type \"done\"");
    		do {
    		  try {
    			inputStr = sc.nextLine();
    			int inputNo = Integer.parseInt(inputStr);
    			
    			  l1.add(inputNo);
    			
    			}catch(NumberFormatException e) {
    				if("done".equalsIgnoreCase(inputStr)) {
    					isFinished = true;
    				}
    				else {
    					throw new Exception("You have entered a non integer. Problem 2 accepts"
    							+ " only numbers");
    				}
    			}
    		}while(!isFinished);
    		
    	}catch(NumberFormatException e) {
    		throw new Exception(e.getMessage());
    	}
    	
    	solveProblem2(l1, ik);
	}
    
    public void promptInputsAndSolveProblem3(Scanner sc) throws Exception {
    	ArrayList<Integer> l1 = new ArrayList<Integer>();
		System.out.println("Enter the numbers to solve problem3. "
				+ "Press enter to input next number. When you are finished, type \"done\"");
		String inputStr = null;
		boolean isFinished = false;
		do {
			try {
			inputStr = sc.nextLine();
			int inputNo = Integer.parseInt(inputStr);
			
			  l1.add(inputNo);
			
			}catch(NumberFormatException e) {
				if("done".equalsIgnoreCase(inputStr)) {
					isFinished = true;
				}
				else {
					throw new Exception("You have entered a non integer. Problem 3 accepts"
							+ " only numbers");
				}
			}
		}while(!isFinished);
		solveProblem3(l1);
	}
    
    public void promptInputsAndSolveProblem4(Scanner sc) throws Exception {
    	ArrayList<String> l1 = new ArrayList<String>();
		System.out.println("Enter the strings to solve problem4. "
				+ "Press enter to input next string. When you are finished, type \"done\"");
		String inputStr = null;
		boolean isFinished = false;
		do {
			
			inputStr = sc.nextLine();
			if("done".equalsIgnoreCase(inputStr)) {
				isFinished = true;
			}else {
			
			  l1.add(inputStr);
			}
			
		}while(!isFinished);
		solveProblem4(l1);
	}
    
    public void promptInputsAndSolveProblem5(Scanner sc) throws Exception {
	 System.out.println("Enter string to check if it is balanced expression.");
	 String inputStr = sc.nextLine();
     solveProblem5(inputStr);
 	}
    
    public void promptInputsAndSolveProblem6(Scanner sc) throws Exception {
    	Stack<Integer> s1 = new Stack<>();
		System.out.println("Enter the numbers to solve problem6. "
				+ "Press enter to input next number. "
				+ "The stack should contain only even number of integers. "
				+ "When you are finished, type \"done\"");
		String inputStr = null;
		boolean isFinished = false;
		do {
			try {
			inputStr = sc.nextLine();
			int inputNo = Integer.parseInt(inputStr);
			
			  s1.push(inputNo);
			
			}catch(NumberFormatException e) {
				if("done".equalsIgnoreCase(inputStr)) {
					isFinished = true;
				}
				else {
					throw new Exception("You have entered a non integer. Problem 6 accepts"
							+ " only numbers");
				}
			}
		}while(!isFinished);
    	if(s1.size() % 2 != 0) {
    		throw new Exception("The size of the stack is not even. Please try again.");
    	}
		
    	solveProblem6(s1);
 	}
    
    public void promptInputsAndSolveProblem7(Scanner sc) throws Exception {
    	Queue<Integer> q1 = new LinkedList<Integer>();
    	System.out.println("Enter the binary numbers (0 OR 1) to solve problem7. "
				+ "Press enter to input next number. "
				+ "The queue should contain only binary digits. "
				+ "When you are finished, type \"done\"");
		String inputStr = null;
		boolean isFinished = false;
		do {
			try {
			inputStr = sc.nextLine();
			int inputNo = Integer.parseInt(inputStr);
			if(inputNo == 1 || inputNo == 0 )
			  q1.add(inputNo);
			else
				throw new Exception("The input should contain either 1 or 0. Please try again");
			
			}catch(NumberFormatException e) {
				if("done".equalsIgnoreCase(inputStr)) {
					isFinished = true;
				}
				else {
					throw new Exception("You have entered a non binary digit. Problem 7 accepts"
							+ " only binary digit");
				}
			}
		}while(!isFinished);
    	solveProblem7(q1);
 	}
    
    public void promptInputsAndSolveProblem8(Scanner sc) throws Exception {
    	
    	Queue<Integer> q1 = new LinkedList<Integer>();
		System.out.println("Enter the numbers to solve problem8. "
				+ "Press enter to input next number. When you are finished, type \"done\"");
		String inputStr = null;
		boolean isFinished = false;
		do {
			try {
			inputStr = sc.nextLine();
			int inputNo = Integer.parseInt(inputStr);
			
			  q1.add(inputNo);
			
			}catch(NumberFormatException e) {
				if("done".equalsIgnoreCase(inputStr)) {
					isFinished = true;
				}
				else {
					throw new Exception("You have entered a non integer. Problem 8 accepts"
							+ " only numbers");
				}
			}
		}while(!isFinished);
    	solveProblem8(q1);
 	}
    
    public void promptInputsAndSolveProblem9(Scanner sc) throws Exception {
    	Queue<Integer> q1 = new LinkedList<Integer>();
    	System.out.println("Enter the numbers to solve problem9. "
				+ "Press enter to input next number. When you are finished, type \"done\"");
		String inputStr = null;
		boolean isFinished = false;
		do {
			try {
			inputStr = sc.nextLine();
			int inputNo = Integer.parseInt(inputStr);
			
			  q1.offer(inputNo);
			
			}catch(NumberFormatException e) {
				if("done".equalsIgnoreCase(inputStr)) {
					isFinished = true;
				}
				else {
					throw new Exception("You have entered a non integer. Problem 9 accepts"
							+ " only numbers");
				}
			}
		}while(!isFinished);
		
		solveProblem9(q1);
 	}
    
    public void promptInputsAndSolveProblem10(Scanner sc) throws Exception {
    	Deque<Character> q1 = new ArrayDeque<Character>();
    	System.out.println("Enter the characters to solve problem10. "
				+ "Press enter to input next character. When you are finished, type \"done\"");
		String inputStr = null;
		boolean isFinished = false;
		do {
			
			inputStr = sc.nextLine();
			if(inputStr.length() == 0 || (inputStr.length() > 1 && !"done".equalsIgnoreCase(inputStr)))
				throw new Exception("This problem accepts only character letters");
			else if("done".equalsIgnoreCase(inputStr)) {
				isFinished = true;
			}
			else{
				char c = inputStr.charAt(0);
				if(Character.isLetter(c))
					q1.add(c);
				else
					throw new Exception("This problem accepts only character letters. Numbers and special chars are not allowed");
			}
			
			
			
			
		}while(!isFinished);
		 int counter = q1.size();
		 System.out.println("Enter the  binary digit to perform operation on deque. "
					+ "Press enter to input next binary digit operation. When you are finished, type \"done\"");
		 
		 List<Integer> list = new ArrayList<Integer>();
		 while(counter > 0) {
			inputStr = sc.nextLine();
			try {
			int inputNo = Integer.parseInt(inputStr);
			if(inputNo == 1 || inputNo == 0 ) {
				
				list.add(inputNo);
				counter--;
			}
			else
					throw new Exception("The input should contain either 1 or 0. Please try again");
			
			}
			catch(NumberFormatException e) {
				if("done".equalsIgnoreCase(inputStr)) {
					counter = -1;
				}
				else {
					throw new Exception("You have entered a non integer. Problem 10 accepts"
							+ " only binary digits for operations");
				}
			}
		}
		int[] arr = list.stream()
         .mapToInt(Integer::intValue)
         .toArray();
		
		 solveProblem10(q1, arr);
		
 	}
    
    
	public LinkedList<Integer> solveProblem1(LinkedList<Integer> l1) {
		System.out.println("Input (L1): " + l1.toString());
	    LinkedList<Integer> l2 = new LinkedList<Integer>();
	    int sum = 0;
	    for(Integer number : l1) {
	    	sum = 0;
		    for(int i = 1 ; i < number ; i++) {
				if(number % i == 0)  {
					sum = sum + i;
				}
			}
			if (sum == number) {
				l2.add(number);
			}
	    }
	    System.out.println("Output (L2): " + l2.toString());
		return l2;
	}
	
	
	public LinkedList<List<Integer>> solveProblem2(LinkedList<Integer> l1, int k) {
		LinkedList<List<Integer>> l2 = new LinkedList<List<Integer>>();
		System.out.println("Input (L1): " + l1.toString() + ", K=" + k);
		for(int i=0; i < l1.size(); i++) {
			if(i != l1.size()-1 && l1.get(i) + l1.get(i+1) == k) {
				List<Integer> al = new ArrayList<Integer>();
				al.add(l1.get(i));
				al.add(l1.get(i+1));
				l2.add(al);
			}
		}
		System.out.println("Output (L2): " + l2.toString());
		return l2;
	}
	
	public int solveProblem3(ArrayList<Integer> a1) {
		int maxInt = Integer.MIN_VALUE;
		System.out.println("Input (A1): " + a1.toString());
		for(int number : a1) {
			if(number > maxInt)
			   maxInt = number;
		}
		System.out.println("Output: " + maxInt);
		return maxInt;
	}
	
	public ArrayList<String> solveProblem4(ArrayList<String> a1){
		ArrayList<String> a2 = new ArrayList<String>(a1);
		System.out.println("Input (A1): " + a1.toString());
		Collections.sort(a2, new Comparator<String>() {
			@Override
			public int compare(String o1, String o2) {
				if(o1.length() < o2.length())
					return -1;
				if(o1.length() > o2.length())
					return 1;
				else
				    return 0;
			}
		});
		System.out.println("Onput (A2): " + a2.toString());
		return a2;
	}
	
	public boolean solveProblem5(String str) {
		System.out.println("Input: " + str);
		boolean isBalanced = false;
		boolean isValid = true;
		if (null == str || ((str.length() % 2) != 0)) {
			isValid = false;
		} else {
		    char[] ch = str.toCharArray();
		    for (char c : ch) {
		        if (!(c == '{' || c == '[' || c == '(' || c == '}' || c == ']' || c == ')')) {
		        	isValid = false;
		        	break;
		        }
		    }
		}
		if(isValid) {
			while (str.contains("()") || str.contains("[]") || str.contains("{}")) {
			    str = str.replaceAll("\\(\\)", "")
			      .replaceAll("\\[\\]", "")
			      .replaceAll("\\{\\}", "");
			}
			if(str.length() == 0)
				isBalanced = true;
		}
		System.out.println("Output: " + isBalanced);
		return isBalanced;
	}
	
	public ArrayList<Integer> solveProblem6(Stack<Integer> s)
    {
		System.out.println("Input(S): " + s.toString());
    	ArrayList<Integer> a = new ArrayList<>();
    	int size = s.size() / 2;
    	for(int i = 0; i < size ; i++) 
    	{
    		a.add(s.pop());
    	}
    	s.sort(Collections.reverseOrder());
    	for(int i = 0; i < size ; i++) 
    	{	
    		a.add(s.pop());
    	}
    	System.out.println("Output(A): " + a.toString());
    	return a;
    }
    
    public int solveProblem7(Queue<Integer> q) 
    {	
    	System.out.println("Input(Q): " + q.toString());
    	String string = "";
    	for (Integer item: q) {
    		string += item;
        }
    	int output = Integer.parseInt(string,2);
    	System.out.println("Output: " + output);
    	return output;
    }
    
    public ArrayList<Integer> solveProblem8(Queue<Integer> q)
    {
    	System.out.println("Input(Q): " + q.toString());
    	ArrayList<Integer> a = new ArrayList<>();
    	for(int i=0 ; i < q.size() ; i++) 
    	{
    		q = reversequeue(q);
    		a.add(q.poll());
    		q = reversequeue(q);
    		a.add(q.poll());
    	}
    	System.out.println("Output(A): " + a.toString()); 	
    	return a;
    }
    
    public Queue<Integer> reversequeue(Queue<Integer> queue)
    {
        Stack<Integer> stack = new Stack<>();
        while (!queue.isEmpty()) {
            stack.add(queue.peek());
            queue.remove();
        }
        while (!stack.isEmpty()) {
            queue.add(stack.peek());
            stack.pop();
        }
        return queue;
    }

    public ArrayList<Integer> solveProblem9(Queue<Integer> q1)
    {
    	System.out.println("Input(Q): " + q1.toString());
    	
    	ArrayList<Integer> array = new ArrayList<Integer>();
		
		int size3 = 0;
		
		if (q1.size() % 2 == 0)
			size3 = q1.size() / 2;
		else
			size3 = q1.size() / 2 + 1;


		for (int i=0;i<size3;i++) 
		{ 

		int a = q1.poll();
		int b = -1;

		try {
		b = q1.poll();
		}catch(Exception e) {

		}

		if (a % 2 != 0 && b % 2 == 0) {
			array.add(b);
			if (b != -1)
				array.add(a);
		} else {
			array.add(a);
			if (b != -1)
				array.add(b);
		}

	}
		

    	System.out.println("Output(A): " + array.toString());
    	return array;
    }

    public String solveProblem10(Deque<Character> d, int[] arr)
    {
    	System.out.println("Input(Q): " + d.toString() + " A=" + Arrays.toString(arr));
    	String str = "";
		
    	char a = ' ';
    	for(int i=0;i <= arr.length - 1;i++) {
        if(arr[i] == 1) {
			a = d.poll();
		}else {
			
			if(a != ' ') {
				d.addFirst(a);
				a = ' ';
			}
		}
    	}
        Iterator<Character> itr = d.iterator();
        while (itr.hasNext())
        {
        	str += itr.next();
        }


        System.out.println("Output: " + str);
        return str;
    }
	
	public void exit() {
		System.out.println("Application has been terminated. Please check the errors and try again");
		System.exit(0);
	}
	
	
	
	

}